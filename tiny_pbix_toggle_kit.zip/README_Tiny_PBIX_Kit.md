# Tiny PBIX Kit: Toggle Slicer for Order vs. Ship vs. Invoice

This kit gives you everything to build a **tiny Power BI report** that toggles measures between **Order Date**, **Ship Date**, and **Invoice Date** using a **disconnected slicer + `USERELATIONSHIP`**.

## Files
- `Calendar.csv` — Date dimension with dates from 2024-01-01 to 2024-03-31
- `Sales.csv` — Fact data with `OrderDate`, `ShipDate`, `InvoiceDate`, and `SalesAmount`
- `DateMode.csv` — (Optional) table to use as a disconnected slicer
- `DAX_Measures.txt` — Copy/paste these into Power BI Desktop

## Steps (≈2–3 minutes)
1. **Get data** → Text/CSV → load `Calendar.csv`, `Sales.csv`, and optionally `DateMode.csv`.
2. **Relationships** (Model view):
   - Make the relationship **active**: `Calendar[Date]` → `Sales[OrderDate]` (single direction: Calendar → Sales)
   - Add **inactive** relationships:
     - `Calendar[Date]` → `Sales[ShipDate]`
     - `Calendar[Date]` → `Sales[InvoiceDate]`
3. (Optional) If you **didn’t import** `DateMode.csv`, create it as a calculated table:
   ```DAX
   Date Mode = DATATABLE(
       "DateMode", STRING,
       { {"Order Date"}, {"Ship Date"}, {"Invoice Date"} }
   )
   ```
4. **Create measures**: open `DAX_Measures.txt` and paste into your model (e.g., into a `Measures` table).
5. **Build visuals**:
   - Add a **Slicer** → `Date Mode[DateMode]`
   - Add a **Line chart**
     - X-axis: `Calendar[Date]`
     - Y-axis: `Sales (Toggle Date Context)`
   - (Optional) Add `Sales YTD (Toggle)` to compare trends.

## Notes
- `USERELATIONSHIP` activates the alternate date role **only for the measure** evaluation—your model’s active relationship stays on **Order Date**.
- Time-intel functions (YTD/MTD/LY) follow the **same `Calendar[Date]`**; the slicer just tells the measure which date role to apply.

Enjoy! – Tim’s tiny toggle kit
