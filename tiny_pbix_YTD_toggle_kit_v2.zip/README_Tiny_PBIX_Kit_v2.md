# Tiny PBIX Kit (v2): Toggle + YTD/MTD/LY

**What’s new in v2**: Added three toggle-aware time-intel measures — **YTD**, **MTD**, and **Last Year (LY)** — that follow the slicer selection.

### Quick Steps
1) Import CSVs (Calendar, Sales, DateMode).  
2) Relationships: Active on `OrderDate`; inactive on `ShipDate` and `InvoiceDate`.  
3) Paste measures from `DAX_Measures_v2.txt`.  
4) Build visuals:
   - Slicer: `Date Mode[DateMode]`
   - Line chart: X = `Calendar[Date]`, Y = `Sales (Toggle Date Context)`
   - Add cards/lines for `Sales YTD (Toggle)`, `Sales MTD (Toggle)`, `Sales LY (Toggle)`.

### Notes
- These measures rely on a single contiguous `Calendar[Date]` and one active relationship to `OrderDate`.
- `USERELATIONSHIP` selectively activates Ship/Invoice for each calculation.
